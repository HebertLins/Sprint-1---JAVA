# Sprint-1-JAVA

Nome da Aplicação: Quote Levelling


![image](https://github.com/HebertLins/Sprint-1-JAVA/assets/111543334/cfad3699-e26c-4688-ba36-528b5e970c8a)

GUIA PARA RODAR A APLICAÇÃO:

1 - Deve-se conferir o persistence.xml e alterar para suas credenciais do seu banco de dados, como url, senha, usuario, tipo de banco e etc;

2 - Alterar também o tipo de banco na classe .main;

3 - Rodar a classe .main



# DIAGRAMA DE CLASSES

![DiagramaClasses](https://github.com/HebertLins/Sprint-1-JAVA/assets/111543334/d88861f1-ae62-422e-b37c-13701377550c)


# DER

![DER](https://github.com/HebertLins/Sprint-1-JAVA/assets/111543334/7c4b0a93-33f7-4458-a6b2-acd1de529f18)


# PITCH

https://youtu.be/Q22Nc1Y658I
